package com.backend.trabalhodejava.dto;

public record PessoaDto(String name,String cpf,int idade) {
}
